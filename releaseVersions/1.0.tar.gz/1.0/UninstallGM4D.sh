#!/bin/bash
# scipt to uninstall GM4D
sudo rm -f /usr/share/applications/GM4D.desktop
sudo rm -rf /usr/local/bin/GM4D


